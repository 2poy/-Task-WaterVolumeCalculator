//: A UIKit based Playground for presenting user interface
  
import UIKit
import PlaygroundSupport

class MyViewController : UIViewController {
    
    override func loadView() {
        
        let view = UIView()
        view.backgroundColor = .white

        let label = UILabel()
        label.frame = CGRect(x: 150, y: 320, width: 200, height: 20)
        label.text = "Volume is \(calculateWaterVolume())"
        label.textColor = .black

        view.addSubview(label)
        self.view = view
        
        containerView.frame = CGRect(x: 0, y: 0, width: view.frame.width, height: 637)
        view.addSubview(containerView)

        drawWalls()
        drawWater()
        
    }
    let containerView: UIView = {
        let view = UIView()
        return view
    }()
    
    var waterCordintes: [Cordinates] = []
    var potentialWaterCordintes: [Cordinates] = []
    
    let wallsArray: [Int] = [0, 3, 0, 2, 0, 7 , 0, 0, 0, 2, 1, 4]
    
    func calculateWaterVolume() -> Int {
        // Index in this array is height
        // Value in this array is number of water cubes in this height
        var potentialWater: [Int] = [0, 0, 0, 0, 0, 0, 0]
        // Water volume
        var volume: Int = 0
        // Current max height
        var maxHeight: Int = 0
        for wallIndex in 0...wallsArray.count - 1 {
            /// Check to avoid errors in "for" cycles
            if maxHeight == 0 {
                /// Iterration should be over here
                maxHeight = wallsArray[wallIndex]
                continue
            }
            /// Check for max height
            if wallsArray[wallIndex] >= maxHeight {
                for index in 0...maxHeight - 1 {
                    /// Puting all potential water in volume
                    volume += potentialWater[index]
                    waterCordintes.append(contentsOf: getAllCordinates(with: index))
                    potentialWater[index] = 0
                }
                maxHeight = wallsArray[wallIndex]
                
            } else {
                if wallsArray[wallIndex] != 0 {
                    for index in 0...wallsArray[wallIndex] - 1 {
                        /// Puting all potential water that lower than element in volume
                        volume += potentialWater[index]
                        waterCordintes.append(contentsOf: getAllCordinates(with: index))
                        potentialWater[index] = 0
                      }
                }
                for index in wallsArray[wallIndex]...maxHeight - 1 {
                    /// Adding values to potential water
                    potentialWaterCordintes.append(Cordinates(x: wallIndex, y: index))
                    potentialWater[index] += 1
                }
            }
        }
        print("\(waterCordintes)")
        return volume
    }
    func drawWalls() {
        var x: Int = 0
        var y: Int = 637
        
        for element in wallsArray {
            if element == 0 {
                x += 30
                continue
            }
            for _ in 1...element {
                containerView.layer.addSublayer(createSqure(x: x, y: y))
                y -= 30
            }
            y = 637
            x += 30
        }
        
    }
    func drawWater() {
        for element in waterCordintes {
            containerView.layer.addSublayer(createWaterSqure(x: element.x * 30, y: 637 - element.y * 30))
        }
        
    }

    func createSqure(x: Int, y: Int) -> CAShapeLayer {
        let path = UIBezierPath()
        path.move(to: CGPoint(x: x, y: y))
        path.addLine(to: CGPoint(x: x + 30, y: y))
        path.addLine(to: CGPoint(x: x + 30, y: y + 30))
        path.addLine(to: CGPoint(x: x, y: y + 30))
        path.addLine(to: CGPoint(x: x, y: y))
        
        let shapeLayer = CAShapeLayer()
        shapeLayer.path = path.cgPath
        shapeLayer.fillColor = UIColor(red: 0.66, green: 0.86, blue: 0.51, alpha: 1.0).cgColor
        shapeLayer.strokeColor = UIColor(red: 0, green: 0, blue: 0.38, alpha: 1).cgColor
        shapeLayer.lineWidth = 3
        
        return shapeLayer
    }
    func createWaterSqure(x: Int, y: Int) -> CAShapeLayer {
        let path = UIBezierPath()
        path.move(to: CGPoint(x: x, y: y))
        path.addLine(to: CGPoint(x: x + 30, y: y))
        path.addLine(to: CGPoint(x: x + 30, y: y + 30))
        path.addLine(to: CGPoint(x: x, y: y + 30))
        path.addLine(to: CGPoint(x: x, y: y))
        
        let shapeLayer = CAShapeLayer()
        shapeLayer.path = path.cgPath
        shapeLayer.fillColor = UIColor.blue.cgColor
        shapeLayer.strokeColor = UIColor.blue.cgColor
        shapeLayer.lineWidth = 3
        
        return shapeLayer
    }
    func getAllCordinates(with y: Int) -> [Cordinates] {
        var cordinates: [Cordinates] = []
        if potentialWaterCordintes.count == 0 {
            return cordinates
        }
        for index in 0...potentialWaterCordintes.count - 1 where potentialWaterCordintes[index].y == y {
            cordinates.append(potentialWaterCordintes[index])
        }
        return cordinates
    }
}

struct Cordinates {
    var x: Int
    var y: Int
}
// Present the view controller in the Live View window
PlaygroundPage.current.liveView = MyViewController()
